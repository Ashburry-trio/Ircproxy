#!/usr/bin/python
# -*- coding: utf-8 -*-
import sys
from os import path
_dir = path.dirname(path.abspath(__file__))
sys.path.insert(0, _dir)
